local slider = require("Plugins/simple-slider")
local show = require("Plugins/show")

local gameModel = {}

function gameModel.load()
  numberOfSolvedSequences = 0
  score = 0

  squareDimensions = 300

  gameFont = love.graphics.newFont(50)

  saveData = {}
    saveData.highScore = 0
    saveData.musicVolume = 0.25
    saveData.sfxVolume = 0.25

  if love.filesystem.exists("data.lua") then
    local data = love.filesystem.load("data.lua")
    data()
  end

  backgroundMusic = love.audio.newSource("Music/BackgroundMusic.mp3")
  backgroundMusic:setLooping(true)
  backgroundMusic:setVolume(saveData.musicVolume)
  backgroundMusic:play()

  clickSound = love.audio.newSource("SFX/click1.ogg")
  clickSound:setVolume(saveData.sfxVolume)

  correctSound = love.audio.newSource("SFX/CoinPickup.wav")
  correctSound:setVolume(saveData.sfxVolume)

  colors = {}
    colors.blue = {15, 15, 245}
    colors.red = {245, 15, 15}
    colors.green = {15, 245, 15}
    colors.yellow = {245, 245, 15}
    colors.white = {245, 245, 245}
    colors.grey = {155, 155, 155}
    colors.buttonHighlight = {15, 50, 100}

  blueSquare = {}
    blueSquare.x = 275
    blueSquare.y = 120
    blueSquare.width = squareDimensions
    blueSquare.height = squareDimensions
    blueSquare.color = colors.blue
    blueSquare.currentColor = blueSquare.color
    blueSquare.clicked = false

  redSquare = {}
    redSquare.x = 600
    redSquare.y = 120
    redSquare.width = squareDimensions
    redSquare.height = squareDimensions
    redSquare.color = colors.red
    redSquare.currentColor = redSquare.color
    redSquare.clicked = false

  yellowSquare = {}
    yellowSquare.x = 275
    yellowSquare.y = 445
    yellowSquare.width = squareDimensions
    yellowSquare.height = squareDimensions
    yellowSquare.color = colors.yellow
    yellowSquare.currentColor = yellowSquare.color
    yellowSquare.clicked = false

  greenSquare = {}
    greenSquare.x = 600
    greenSquare.y = 445
    greenSquare.width = squareDimensions
    greenSquare.height = squareDimensions
    greenSquare.color = colors.green
    greenSquare.currentColor = greenSquare.color
    greenSquare.clicked = false

  squares = {}

  nextSequenceButton = {}
    nextSequenceButton.x = 375
    nextSequenceButton.y = 775
    nextSequenceButton.width = 450
    nextSequenceButton.height = 100
    nextSequenceButton.color = colors.grey
    nextSequenceButton.clicked = false

  nextSequenceText = {}
    nextSequenceText.x = nextSequenceButton.x + 37.5
    nextSequenceText.y = nextSequenceButton.y + 20

  scoreText = {}
    scoreText.x = 475
    scoreText.y = 30

  highScoreText = {}
    highScoreText.x = 400
    highScoreText.y = 100

  playButton = {}
    playButton.x = 450
    playButton.y = 250
    playButton.width = 300
    playButton.height = 75
    playButton.color = colors.grey
    playButton.clicked = false

playButtonText = {}
  playButtonText.x = playButton.x + 95
  playButtonText.y = playButton.y + 10

settingsButton = {}
  settingsButton.x = 450
  settingsButton.y = 450
  settingsButton.width = 300
  settingsButton.height = 75
  settingsButton.color = colors.grey

settingsButtonText = {}
  settingsButtonText.x = settingsButton.x + 50
  settingsButtonText.y = settingsButton.y + 10

quitButton = {}
  quitButton.x = 450
  quitButton.y = 650
  quitButton.width = 300
  quitButton.height = 75
  quitButton.color = colors.grey

quitButtonText = {}
  quitButtonText.x = quitButton.x + 95
  quitButtonText.y = quitButton.y + 10

backButton = {}
  backButton.x = 450
  backButton.y = 650
  backButton.width = 300
  backButton.height = 75
  backButton.color = colors.grey

backButtonText = {}
  backButtonText.x = backButton.x + 90
  backButtonText.y = backButton.y + 10

volumeSlider = {}
  volumeSlider.x = 600
  volumeSlider.y = 250
  volumeSlider.length = 450
  volumeSlider.slider = newSlider(volumeSlider.x, volumeSlider.y, volumeSlider.length, saveData.musicVolume, 0, 1,
  function (v)
    saveData.musicVolume = v
    love.filesystem.write("data.lua", table.show(saveData, "saveData"))
    backgroundMusic:setVolume(saveData.musicVolume)
  end)

sfxSlider = {}
  sfxSlider.x = 600
  sfxSlider.y = 500
  sfxSlider.length = 450
  sfxSlider.slider = newSlider(sfxSlider.x, sfxSlider.y, sfxSlider.length, saveData.sfxVolume, 0, 1,
  function (v)
    saveData.sfxVolume = v
    love.filesystem.write("data.lua", table.show(saveData, "saveData"))
    clickSound:setVolume(saveData.sfxVolume)
    correctSound:setVolume(saveData.sfxVolume)
  end)

  table.insert(squares, blueSquare)
  table.insert(squares, redSquare)
  table.insert(squares, yellowSquare)
  table.insert(squares, greenSquare)

    love.window.setMode(1200, 900)
end

return gameModel
