local gameWiev = {}

local graphics = {}

function gameWiev.draw()
  love.graphics.setFont(gameFont)

  if gameState == "mainMenu" then
    love.graphics.setColor(colors.grey)

    graphics:drawRect(playButton.x, playButton.y, playButton.width, playButton.height, playButton.color)
    graphics:drawRect(settingsButton.x, settingsButton.y, settingsButton.width, settingsButton.height, settingsButton.color)
    graphics:drawRect(quitButton.x, quitButton.y, quitButton.width, quitButton.height, quitButton.color)

    love.graphics.setColor(colors.white)

    love.graphics.print("Highscore: " .. saveData.highScore, 435, 100)
    love.graphics.print("Play", playButtonText.x, playButtonText.y)
    love.graphics.print("Settings", settingsButtonText.x, settingsButtonText.y)
    love.graphics.print("Quit", quitButtonText.x, quitButtonText.y)
  end

  if gameState == "settings" then
    love.graphics.setColor(backButton.color)

    graphics:drawRect(backButton.x, backButton.y, backButton.width, backButton.height, backButton.color)

    love.graphics.setColor(colors.white)

    volumeSlider.slider:draw()
    sfxSlider.slider:draw()

    love.graphics.print("Music Volume", 430, 150)
    love.graphics.print("SFX Volume", 460, 400)
    love.graphics.print("Back", backButtonText.x, backButtonText.y)
  end

  if gameState == "playing" then
    for i=1, #squares do
      graphics:drawRect(squares[i].x, squares[i].y, squares[i].width, squares[i].height, squares[i].currentColor)
    end

    love.graphics.setColor(colors.white)
    love.graphics.print("Score: " .. score, scoreText.x, scoreText.y)
    love.graphics.print("Match the pattern by clicking on the buttons", 50, 800)

    if sequenceState == "correct" then
      graphics:drawRect(nextSequenceButton.x, nextSequenceButton.y, nextSequenceButton.width, nextSequenceButton.height, nextSequenceButton.color)

      love.graphics.setColor(colors.white)
      love.graphics.print("Next Sequence", nextSequenceText.x, nextSequenceText.y)
    end
  end
end

function graphics:setColor(c)
  if self.lastcolor ~= c then
    self.lastcolor = c
    love.graphics.setColor(c)
  end
  return self
end

function graphics:drawRect(x, y, w, h, c)
  if c then
    self:setColor(c)
  end
  love.graphics.rectangle("fill", x, y, w, h)
  return self
end

return gameWiev
