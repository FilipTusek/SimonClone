local inputManager = require("Scripts/inputManager")
local show = require("Plugins/show")

local gameController = {}

local timeBetweenTwoSquares = 0.5
local currentTimer = -1
local sequenceLength = 4
local currentLength = 0

local transitionTimer = 0.25
local currentTransition = -1

local correctSquares = 0

local randomNumber = 0

local currentSequence = {}
local playerSequence = {}

 showNewSequence = false

function gameController.update(dt)
  if gameState == "playing" then
    gameController.showSequence(dt)
  end

  if gameState == "settings" then
    volumeSlider.slider:update()
    sfxSlider.slider:update()
  end
end

function gameController.showSequence(dt)
  if sequenceState == "newSequence" then
    if currentTimer == -1 then
      currentTransition = transitionTimer
      currentTimer = timeBetweenTwoSquares
      math.randomseed(love.timer.getTime())
      randomNumber = math.random(1, #squares)

      squares[randomNumber].currentColor = colors.white

      table.insert(currentSequence, randomNumber)
    end

    if currentTimer > 0 then
      currentTimer = currentTimer - dt
    end

    if currentTimer <= 0 then

      squares[randomNumber].currentColor = squares[randomNumber].color

      if currentTransition > 0 then
        currentTransition = currentTransition - dt
      end

      if currentTransition <= 0 then
        currentTimer = -1

        if currentLength < sequenceLength - 1 then
          currentLength = currentLength + 1
        else
          currentLength = 0
          sequenceState = "waitingForInput"
        end
      end
    end
  end
end

function love.mousemoved(x, y, dx, dy)
  inputManager.mousemoved(x, y, dx, dy)
end

function love.mousepressed(x, y, button, isTouch)
  inputManager.mousepressed(x, y, button, isTouch)

  if sequenceState == "waitingForInput" then
    if currentLength < sequenceLength then
      for i = 1, #squares do
        if squares[i].clicked then
          squares[i].clicked = false
          squares[i].currentColor = colors.white
          table.insert(playerSequence, i)
          currentLength = currentLength + 1
        end
      end
    end
    if currentLength == sequenceLength then
      for i = 1, #currentSequence do
        if currentSequence[i] == playerSequence[i] then
          correctSquares = correctSquares + 1
        else
          if numberOfSolvedSequences > saveData.highScore then
            saveData.highScore = numberOfSolvedSequences
            love.filesystem.write("data.lua", table.show(saveData, "saveData"))
          end
          gameState = "mainMenu"
          sequenceLength = 4
          currentLength = 0
          currentSequence = {}
          playerSequence = {}
        end
      end

      if correctSquares >= sequenceLength then
        numberOfSolvedSequences = numberOfSolvedSequences + 1
        correctSound:play()
        sequenceState = "correct"
        currentLength = 0
        sequenceLength = sequenceLength + 1
        score = score + 1
        currentSequence = {}
        playerSequence = {}

        for i = 1, #squares do
          squares[i].clicked = false
          squares[i].currentColor = squares[i].color
        end
      end
    end
  end
end

function love.mousereleased(x, y, button, isTouch)
  inputManager.mousereleased(x, y, button, isTouch)

  if sequenceState == "waitingForInput" then
    for i = 1, #squares do
      if squares[i].clicked == false then
        squares[i].currentColor = squares[i].color
      end
    end
  end
end

function love.keypressed(key, scancode, isrepeat)
  if key == "escape" then
    love.event.quit(0)
  end
end

return gameController
