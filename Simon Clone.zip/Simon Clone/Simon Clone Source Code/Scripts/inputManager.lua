local inputManager = {}

function inputManager.mousemoved(x, y, dx, dy)
  if gameState == "mainMenu" then
    if inputManager.checkIfMouseOver(x, y, playButton) then
      playButton.color = colors.buttonHighlight
    else
      playButton.color = colors.grey
    end

    if inputManager.checkIfMouseOver(x, y, settingsButton) then
      settingsButton.color = colors.buttonHighlight
    else
      settingsButton.color = colors.grey
    end

    if inputManager.checkIfMouseOver(x, y, quitButton) then
      quitButton.color = colors.buttonHighlight
    else
      quitButton.color = colors.grey
    end
  end

  if gameState == "settings" then
    if inputManager.checkIfMouseOver(x, y, backButton) then
      backButton.color = colors.buttonHighlight
    else
      backButton.color = colors.grey
    end
  end

  if gameState == "playing" then
    if inputManager.checkIfMouseOver(x, y, nextSequenceButton) then
      nextSequenceButton.color = colors.buttonHighlight
    else
      nextSequenceButton.color = colors.grey
    end
  end
end

function inputManager.mousepressed(x, y, button, isTouch)
  if gameState == "playing" then
    if sequenceState == "waitingForInput" then
      if button == 1 then
        for i = 1, #squares do
          if inputManager.checkIfMouseOver(x, y, squares[i]) then
            squares[i].clicked = true
          end
        end
      end
    end

    if sequenceState == "correct" then
      if inputManager.checkIfMouseOver(x, y, nextSequenceButton) then
        clickSound:play()
        sequenceState = "newSequence"
      end
    end
  end

  if gameState == "mainMenu" then
    if button == 1 then
      if inputManager.checkIfMouseOver(x, y, playButton) then
        clickSound:play()
        gameState = "playing"
        sequenceState = "newSequence"
        numberOfSolvedSequences = 0
      end

      if inputManager.checkIfMouseOver(x, y, settingsButton) then
        clickSound:play()
        gameState = "settings"
      end

      if inputManager.checkIfMouseOver(x, y, quitButton) then
        clickSound:play()
        love.event.quit(0)
      end
    end
  end

  if gameState == "settings" then
    if button == 1 then
      if inputManager.checkIfMouseOver(x, y, backButton) then
        clickSound:play()
        gameState = "mainMenu"
      end
    end
  end
end

function inputManager.mousereleased(x, y, button, isTouch)
  if gameState == "playing" then
    if sequenceState == "waitingForInput" then
      if button == 1 then
        for i = 1, #squares do
          if inputManager.checkIfMouseOver(x, y, squares[i]) then
            squares[i].clicked = false;
          end
        end
      end
    end
  end
end

function inputManager.checkIfMouseOver(mouseX, mouseY, target)
  if mouseX >= target.x and mouseX < target.x + target.width and mouseY >= target.y and mouseY < target.y + target.height then
    return true
  else
    return false
  end
end

return inputManager
