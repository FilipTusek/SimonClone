local gameModel = require("Scripts/gameModel")
local gameWiev = require("Scripts/gameWiev")
local gameController = require("Scripts/gameController")

gameState = "mainMenu"
sequenceState = "waitingForInput"

function love.load()
  gameModel.load()
end

function love.update(dt)
  gameController.update(dt)
end

function love.draw()
  gameWiev.draw()
end
